import gradio as gr
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

# Sample dataset
data = {
    "url_length": [20, 30, 45, 80, 15, 35, 60, 22, 47, 90],
    "num_dots": [1, 2, 3, 4, 1, 3, 4, 2, 3, 5],
    "https": [1, 0, 1, 0, 1, 0, 1, 1, 0, 0],
    "phishing": [0, 1, 0, 1, 0, 1, 1, 0, 1, 1]
}
df = pd.DataFrame(data)

# Model training
X = df.drop(columns=["phishing"])
y = df["phishing"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Prediction function
def check_urls(urls):
    url_list = urls.split("\n")
    results = []
    for url in url_list:
        url = url.strip()
        url_length = len(url)
        num_dots = url.count(".")
        https = 1 if url.startswith("https") else 0
        features = np.array([[url_length, num_dots, https]])
        prediction = model.predict(features)[0]
        results.append(f"{url} → {'Phishing ❌' if prediction == 1 else 'Legitimate ✅'}")
    return "\n".join(results)

# Web UI
iface = gr.Interface(
    fn=check_urls, 
    inputs=gr.Textbox(lines=10, placeholder="Enter multiple URLs (one per line)"), 
    outputs="text", 
    title="🛡️ PhishShield – AI-Powered URL Scanner",
    description="🔍 Enter URLs to check if they are **Legitimate ✅** or **Phishing ❌**."
)

# Run in Hugging Face Spaces
iface.launch()
