# 🛡️ PhishShield – AI-Powered URL Scanner

## 📌 About
PhishShield is an AI-based web tool that detects **phishing URLs**.  
Simply enter multiple URLs, and it will tell you whether they are **legitimate ✅** or **phishing ❌**.

## 🚀 Features
- Uses **RandomForestClassifier** for high accuracy 🚀
- Check **multiple URLs** at once
- Simple and **user-friendly web interface**

## 🔧 How to Run Locally
1. Install dependencies:  
   ```bash
   pip install -r requirements.txt
   ```
2. Run the app:  
   ```bash
   python app.py
   ```
3. Open in browser at `http://localhost:7860`  

## 🌐 Deploy on Hugging Face Spaces
1. Create a new **Hugging Face Space**  
2. Upload **app.py** and **requirements.txt**  
3. Click **"Deploy"** and get your **permanent public link!**  

---  
👨‍💻 **Developed by:** Your Name  
📅 **Date:** 2025  
